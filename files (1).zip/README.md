```markdown
# GitHub Pages link for two Calendly pages

This repo contains two simple HTML pages you can publish with GitHub Pages to provide a single GitHub URL that leads to your two Calendly links.

Files:
- `index.html` — a small landing page with two big buttons (opens each Calendly link in a new tab).
- `index-auto.html` — attempts to open both Calendly links automatically (may be blocked by browsers).

Calendly links used:
- https://calendly.com/knappzacha/behavioral-health
- https://calendly.com/knappzacha/physical-therapy

Suggested steps to publish (using your GitHub account `knappzacha`):

1. Create a new repository named `knappzacha.github.io`.
   - On GitHub: New repository → Repository name: `knappzacha.github.io` → Public.
2. Add `index.html` (and `index-auto.html` if you want) to the repo and commit.
   - You can create files directly in the web UI or push from your machine:
     ```
     git init
     git add index.html index-auto.html README.md
     git commit -m "Add Calendly landing page"
     git branch -M main
     git remote add origin https://github.com/knappzacha/knappzacha.github.io.git
     git push -u origin main
     ```
3. Because the repo is named `knappzacha.github.io`, GitHub Pages will serve `index.html` at:
   - https://knappzacha.github.io/
4. If you prefer a repository with a different name, enable GitHub Pages in the repo settings and pick the branch/folder that contains `index.html`. The published URL will be shown in the Pages settings.

Notes:
- If you want the link to automatically open both Calendly pages as soon as someone visits, use `index-auto.html` (but modern browsers often block multiple programmatic opens as popups).
- If you want a short link that redirects automatically to one selected Calendly link, create a tiny HTML file with a meta refresh or a server-side redirect — but for serving two choices, the landing page above is the cleanest cross-browser option.
```